public class Enemigo  extends Entidad{

    public Enemigo(String nombre, double vida, double daño, double especial) {
        super(nombre, vida, daño, especial);
        
    }

    
    
}
